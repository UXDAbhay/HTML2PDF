<?php
$fname=$_POST["firstname"];
$myage=$_POST["age"];
$myreligion=$_POST["religion"];
$addr=$_POST["address"];
$textarea=$_POST["text"];
$dob=$_POST["bday"];
$pob=$_POST["place"];
$place=$_POST["enterplace"];
$date=$_POST["enterdate"];

if(empty($fname) || empty($myage) || empty($myreligion) || empty($addr) || empty($textarea) || empty($dob) || empty($pob) || empty($place) || empty($date))       
{?> <script type="text/javascript">
    alert("All Fields Are Required!!");
     history.back();
  </script><?php



}
	else {

require('fpdf/fpdf_protection.php');





$pdf=new FPDF_Protection();
$pdf->SetProtection(array('print'));
$pdf->AddPage();

$pdf->SetFont('times','',21);
$pdf->SetTextColor(177,63,67);
$pdf->Text(85,20,"AFFIDAVIT");


$pdf->SetFont('times','',18);
$pdf->SetTextColor(51,51,51);
$pdf->Text(20,45,"I , the undersigned, $fname  aged $myage , $myreligion by religion, ");
$pdf->Text(20,55,"presently residing at $addr do hereby solemnly affirm and ");
$pdf->Text(20,65,"declare on oath that :");
$pdf->Text(20,85,"$textarea");
$pdf->Text(20,95,"I hereby declare that: ");

$pdf->Text(20,105,"1. I am the deponent herein and a citizen of nationality of the ");
$pdf->Text(20,115,"person's Nationality.");
$pdf->Text(20,125,"2. I was born on  $dob , at  $pob ");
$pdf->Text(20,135,"So I do hereby solemnly affirm that foregoing are true and"); 
$pdf->Text(20,145,"correct statements."); 
$pdf->Text(20,165,"Place: $place");
$pdf->Text(20,175,"Date: $date");
$pdf->Text(20,185,"-----------------------");
$pdf->Text(20,195,"Deponent Name:");
$pdf->Text(20,215,"Signature :");
$pdf->Text(20,240,"Please contact us for further queries if any");
$pdf->Text(20,250,"contact@testsite.com | +91-**********");
$pdf->Output();



}



?>